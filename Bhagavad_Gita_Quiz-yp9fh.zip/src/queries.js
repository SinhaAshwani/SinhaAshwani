import { HttpError } from 'wasp/server'

export const getRandomQuestions = async ({ chapter }, context) => {
  if (!context.user) { throw new HttpError(401) }

  const questions = await context.entities.Question.findMany({
    where: { chapter },
    orderBy: { id: 'asc' },
    take: 10
  });

  if (questions.length < 10) {
    throw new HttpError(404, 'Not enough questions available for the specified chapter.');
  }

  return questions.sort(() => 0.5 - Math.random()).slice(0, 10);
}

export const getQuizResults = async ({ quizSessionId }, context) => {
  if (!context.user) { throw new HttpError(401) }

  const quizSession = await context.entities.QuizSession.findUnique({
    where: { id: quizSessionId },
    include: {
      answers: true,
      questions: true
    }
  });

  if (!quizSession) throw new HttpError(404, 'Quiz session not found.');
  if (quizSession.userId !== context.user.id) throw new HttpError(403, 'Not authorized to view this quiz session.');

  let correctAnswers = 0;
  const results = quizSession.answers.map(answer => {
    const question = quizSession.questions.find(q => q.id === answer.questionId);
    const isCorrect = question.correctOptionIndex === answer.selectedOptionIndex;
    if (isCorrect) correctAnswers++;
    return {
      questionText: question.questionText,
      userAnswer: question[`options`][answer.selectedOptionIndex],
      correctAnswer: question[`options`][question.correctOptionIndex],
      isCorrect,
      verseNumber: `${question.chapter}:${question.verse}`,
      explanation: question.explanation
    };
  });

  const score = correctAnswers;
  const passStatus = score >= 7;

  return {
    results,
    score,
    passStatus,
    pieChartData: {
      labels: ['Correct', 'Incorrect'],
      values: [correctAnswers, quizSession.questions.length - correctAnswers]
    }
  };
}
