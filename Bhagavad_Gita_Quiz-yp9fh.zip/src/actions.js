import { HttpError } from 'wasp/server'

export const startQuizSession = async ({ chapterSelected }, context) => {
  if (!context.user) { throw new HttpError(401) }

  const questions = await context.entities.Question.findMany({
    where: { chapter: chapterSelected },
    take: 10,
    orderBy: {
      id: 'asc'
    }
  });

  const quizSession = await context.entities.QuizSession.create({
    data: {
      user: { connect: { id: context.user.id } },
      chapterSelected,
      questions: { connect: questions.map(q => ({ id: q.id })) }
    }
  });

  return quizSession;
}

export const submitAnswers = async ({ quizSessionId, answers }, context) => {
  if (!context.user) { throw new HttpError(401) }

  const quizSession = await context.entities.QuizSession.findUnique({
    where: { id: quizSessionId },
    include: { questions: true }
  });

  if (!quizSession || quizSession.userId !== context.user.id) {
    throw new HttpError(403);
  }

  if (quizSession.questions.length !== answers.length) {
    throw new HttpError(400, 'All questions must be answered.');
  }

  const answerPromises = answers.map(answer => {
    return context.entities.Answer.create({
      data: {
        quizSessionId: quizSessionId,
        questionId: answer.questionId,
        selectedOptionIndex: answer.selectedOptionIndex
      }
    });
  });

  await Promise.all(answerPromises);

  return { message: 'Answers submitted successfully.' };
}
