import React from 'react';
import { useQuery } from 'wasp/client/operations';
import { getQuizResults } from 'wasp/client/operations';
import { Link } from 'wasp/client/router';
import { Pie } from 'react-chartjs-2';

const ResultPage = () => {
  const { data: quizResults, isLoading, error } = useQuery(getQuizResults, {
    quizSessionId: /* provide session ID */
  });

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error.message;

  const pieData = {
    labels: quizResults.pieChartData.labels,
    datasets: [
      {
        data: quizResults.pieChartData.values,
        backgroundColor: ['#4CAF50', '#FF6384'],
      },
    ],
  };

  return (
    <div className="p-4 bg-slate-50 rounded-lg">
      <h1 className="text-2xl font-bold mb-4">Quiz Results</h1>
      <p className="mb-2">Score: {quizResults.score}/10</p>
      <p className="mb-4">Status: {quizResults.passStatus ? 'Pass' : 'Fail'}</p>
      <div className="mb-4">
        <Pie data={pieData} />
      </div>
      <Link
        to="/select-chapter"
        className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
      >
        Retake Quiz
      </Link>
    </div>
  );
};

export default ResultPage;
