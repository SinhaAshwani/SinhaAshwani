import React from 'react';
import { useQuery } from 'wasp/client/operations';
import { getQuizResults } from 'wasp/client/operations';
import { Link } from 'wasp/client/router';

const ReviewPage = () => {
  const { data: quizResults, isLoading, error } = useQuery(getQuizResults);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  return (
    <div className='p-6 bg-white max-w-4xl mx-auto rounded-lg shadow-md'>
      <h2 className='text-2xl font-bold mb-4'>Review Your Answers</h2>
      <div className='space-y-4'>
        {quizResults.results.map((result, index) => (
          <div key={index} className={`p-4 rounded-lg ${result.isCorrect ? 'bg-green-100' : 'bg-red-100'}`}>
            <h3 className='font-semibold'>Verse: {result.verseNumber}</h3>
            <p className='mb-1'><strong>Question:</strong> {result.questionText}</p>
            <p className='mb-1'><strong>Your Answer:</strong> {result.userAnswer}</p>
            <p className='mb-1'><strong>Correct Answer:</strong> {result.correctAnswer}</p>
            <p className='italic'><strong>Explanation:</strong> {result.explanation}</p>
          </div>
        ))}
      </div>
      <Link
        to='/result'
        className='mt-6 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded'
      >
        View Result
      </Link>
    </div>
  );
};

export default ReviewPage;
