import React, { useState } from 'react';
import { useQuery, useAction } from 'wasp/client/operations';
import { getRandomQuestions, submitAnswers } from 'wasp/client/operations';

const QuizPage = () => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState([]);
  const { data: questions, isLoading, error } = useQuery(getRandomQuestions, { chapter: 'Chapter 1' });
  const submitAnswersFn = useAction(submitAnswers);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error.message;

  const handleOptionSelect = (optionIndex) => {
    const newSelectedAnswers = [...selectedAnswers];
    newSelectedAnswers[currentQuestionIndex] = optionIndex;
    setSelectedAnswers(newSelectedAnswers);
  };

  const handleNext = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      submitAnswersFn({
        quizSessionId: 1, // Replace with actual session ID
        answers: selectedAnswers.map((optionIndex, idx) => ({
          questionId: questions[idx].id,
          selectedOptionIndex: optionIndex
        }))
      });
    }
  };

  return (
    <div className='p-4'>
      <div className='bg-white p-4 rounded shadow'>
        <h2 className='text-xl font-bold mb-4'>Question {currentQuestionIndex + 1}</h2>
        <p className='mb-4'>{questions[currentQuestionIndex].questionText}</p>
        <div className='mb-4'>
          {questions[currentQuestionIndex].options.map((option, index) => (
            <div key={index} className='mb-2'>
              <label className='flex items-center'>
                <input
                  type='radio'
                  name='option'
                  value={index}
                  checked={selectedAnswers[currentQuestionIndex] === index}
                  onChange={() => handleOptionSelect(index)}
                  className='mr-2'
                />
                {option}
              </label>
            </div>
          ))}
        </div>
        <button
          onClick={handleNext}
          className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded'
        >
          {currentQuestionIndex < questions.length - 1 ? 'Next' : 'Submit'}
        </button>
      </div>
    </div>
  );
};

export default QuizPage;
