import React, { useState } from 'react';
import { useHistory, Link } from 'wasp/client/router';

const UserDetailsPage = () => {
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const history = useHistory();

  const handleStartQuiz = () => {
    if (name && mobile) {
      history.push('/select-chapter'); // Redirect to ChapterSelectionPage
    } else {
      alert('Please provide a name and mobile number.');
    }
  };

  return (
    <div className="p-6 max-w-lg mx-auto bg-white rounded-xl shadow-md space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700">Name</label>
        <input
          type="text"
          className="mt-1 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700">Mobile Number</label>
        <input
          type="tel"
          className="mt-1 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
          value={mobile}
          onChange={(e) => setMobile(e.target.value)}
          required
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700">Email (optional)</label>
        <input
          type="email"
          className="mt-1 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
      </div>
      <div className="pt-4">
        <button
          onClick={handleStartQuiz}
          className="w-full bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
        >
          Start Quiz
        </button>
      </div>
    </div>
  );
};

export default UserDetailsPage;
