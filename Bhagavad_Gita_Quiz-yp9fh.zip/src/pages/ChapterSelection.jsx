import React, { useState } from 'react';
import { useAction } from 'wasp/client/operations';
import { startQuizSession } from 'wasp/client/operations';
import { useHistory } from 'wasp/client/router';

const ChapterSelectionPage = () => {
  const [selectedChapter, setSelectedChapter] = useState('');
  const startQuizSessionFn = useAction(startQuizSession);
  const history = useHistory();

  const chapters = [
    "All Chapters", "Chapter 1", "Chapter 2", "Chapter 3", "Chapter 4", "Chapter 5",
    "Chapter 6", "Chapter 7", "Chapter 8", "Chapter 9", "Chapter 10", "Chapter 11",
    "Chapter 12", "Chapter 13", "Chapter 14", "Chapter 15", "Chapter 16", "Chapter 17", "Chapter 18"
  ];

  const handleContinue = async () => {
    if (!selectedChapter) {
      alert('Please select a chapter.');
      return;
    }
    try {
      const quizSession = await startQuizSessionFn({ chapterSelected: selectedChapter });
      history.push(`/quiz/${quizSession.id}`);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Select Chapter</h1>
      <select
        value={selectedChapter}
        onChange={e => setSelectedChapter(e.target.value)}
        className="block w-full p-2 border rounded mb-4"
      >
        <option value="">Select a chapter...</option>
        {chapters.map(chapter => (
          <option key={chapter} value={chapter}>{chapter}</option>
        ))}
      </select>
      <button
        onClick={handleContinue}
        className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
      >
        Continue
      </button>
    </div>
  );
};

export default ChapterSelectionPage;
